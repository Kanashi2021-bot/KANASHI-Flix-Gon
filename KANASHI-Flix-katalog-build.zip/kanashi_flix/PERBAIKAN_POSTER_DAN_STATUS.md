# KANASHI-Flix — perbaikan dukungan poster

Perubahan pada versi ini:
- Menambahkan `posterUrl` pada model judul.
- Kartu katalog dan dialog detail menampilkan poster dengan Coil.
- Aplikasi mencoba mencari gambar sampul berdasarkan judul melalui AniList GraphQL saat poster belum tersedia.
- URL poster judul kustom ikut disimpan.

Batasan penting:
- Ini **belum** mengintegrasikan seluruh katalog Otakudesu/AniChin.
- Ini **belum** menyediakan URL streaming untuk episode. ExoPlayer hanya bisa memutar URL media yang valid dan dapat diakses, bukan otomatis URL halaman sumber.
- Pencarian poster memakai layanan metadata pihak ketiga dan hasilnya bisa tidak ditemukan atau berbeda untuk judul lokal/alias tertentu.
- ZIP sumber yang diterima tidak menyertakan `gradlew`, `gradle/wrapper`, `google-services.json`, atau keystore release. Karena itu APK tidak dapat dibangun/diverifikasi dari ZIP ini secara langsung di lingkungan ini. Gunakan Android Studio/AndroidIDE dengan Gradle wrapper yang sesuai, dan konfigurasi Firebase hanya jika fitur tersebut memang dipakai.
