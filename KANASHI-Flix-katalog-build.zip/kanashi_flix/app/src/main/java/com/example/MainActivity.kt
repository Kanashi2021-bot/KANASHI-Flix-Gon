package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.ScreenTab
import com.example.ui.components.KanashiBottomNav
import com.example.ui.components.KanashiTopHeader
import com.example.ui.dialogs.AdBreakDialog
import com.example.ui.dialogs.AdminDialog
import com.example.ui.dialogs.AvatarDialog
import com.example.ui.dialogs.DetailDialog
import com.example.ui.dialogs.MeditationDialog
import com.example.ui.dialogs.PaymentDialog
import com.example.ui.screens.CatalogScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.VipScreen
import com.example.ui.screens.WatchScreen
import com.example.ui.theme.BloodBg
import com.example.ui.theme.BloodDeep
import com.example.ui.theme.BloodPrimary
import com.example.ui.theme.CinzelFontFamily
import com.example.ui.theme.KanashiTheme
import com.example.ui.theme.QiGold
import com.example.ui.theme.SpiritJade
import com.example.ui.theme.TextPrimary
import com.example.viewmodel.KanashiViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KanashiTheme {
                KanashiApp()
            }
        }
    }
}

@Composable
fun KanashiApp(viewModel: KanashiViewModel = viewModel()) {
    val context = LocalContext.current
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val activeWatchTitle by viewModel.activeWatchTitle.collectAsStateWithLifecycle()
    val activeWatchEpisode by viewModel.activeWatchEpisode.collectAsStateWithLifecycle()
    val detailModalTitle by viewModel.detailModalTitle.collectAsStateWithLifecycle()

    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val titles by viewModel.titles.collectAsStateWithLifecycle()
    val filteredTitles by viewModel.filteredTitles.collectAsStateWithLifecycle()
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val comments by viewModel.comments.collectAsStateWithLifecycle()
    val announcements by viewModel.announcements.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()

    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedGenre by viewModel.selectedGenre.collectAsStateWithLifecycle()
    val selectedStatus by viewModel.selectedStatus.collectAsStateWithLifecycle()
    val selectedSort by viewModel.selectedSort.collectAsStateWithLifecycle()

    val showPaymentDialog by viewModel.showPaymentDialog.collectAsStateWithLifecycle()
    val showAvatarDialog by viewModel.showAvatarDialog.collectAsStateWithLifecycle()
    val showAdminDialog by viewModel.showAdminDialog.collectAsStateWithLifecycle()
    val showMeditationDialog by viewModel.showMeditationDialog.collectAsStateWithLifecycle()
    val showAdModal by viewModel.showAdModal.collectAsStateWithLifecycle()
    val levelUpCelebration by viewModel.levelUpCelebration.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    // Handle back button
    BackHandler(enabled = activeWatchTitle != null) {
        viewModel.closeWatch()
    }

    BackHandler(enabled = activeWatchTitle == null && detailModalTitle != null) {
        viewModel.closeDetail()
    }

    BackHandler(enabled = activeWatchTitle == null && detailModalTitle == null && currentTab != ScreenTab.HOME) {
        viewModel.selectTab(ScreenTab.HOME)
    }

    // Handle toast messages
    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    Scaffold(
        containerColor = BloodBg,
        topBar = {
            if (activeWatchTitle == null) {
                KanashiTopHeader(
                    user = userProfile,
                    isAdmin = isAdmin,
                    onAvatarClick = { viewModel.openAvatarModal() },
                    onAdminClick = { viewModel.openAdmin() },
                    onSearchClick = { viewModel.selectTab(ScreenTab.CATALOG) },
                    modifier = Modifier.statusBarsPadding()
                )
            }
        },
        bottomBar = {
            if (activeWatchTitle == null) {
                KanashiBottomNav(
                    currentTab = currentTab,
                    favoritesCount = favorites.size,
                    historyCount = history.size,
                    onTabSelected = { viewModel.selectTab(it) }
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Screen switcher
            if (activeWatchTitle != null) {
                val currentTitle = activeWatchTitle!!
                WatchScreen(
                    title = currentTitle,
                    episode = activeWatchEpisode,
                    user = userProfile,
                    isFavorite = favorites.contains(currentTitle.id),
                    comments = comments.filter { it.titleId == currentTitle.id },
                    onBackClick = { viewModel.closeWatch() },
                    onChangeEpisode = { viewModel.changeEpisode(it) },
                    onToggleFavorite = { viewModel.toggleFavorite(currentTitle.id) },
                    onPostComment = { viewModel.postComment(currentTitle.id, activeWatchEpisode, it) },
                    onLikeComment = { viewModel.toggleCommentLike(it) }
                )
            } else {
                when (currentTab) {
                    ScreenTab.HOME -> {
                        HomeScreen(
                            titles = titles,
                            user = userProfile,
                            favorites = favorites,
                            history = history,
                            announcements = announcements,
                            selectedCategory = selectedCategory,
                            onCategorySelected = {
                                viewModel.setCategory(it)
                                if (it != "Semua") viewModel.selectTab(ScreenTab.CATALOG)
                            },
                            onTitleClick = { viewModel.openDetail(it) },
                            onFavoriteToggle = { viewModel.toggleFavorite(it) },
                            onWatchClick = { title, ep -> viewModel.openWatch(title, ep) },
                            onMeditationClick = { viewModel.openMeditation() },
                            onExploreCatalog = { viewModel.selectTab(ScreenTab.CATALOG) }
                        )
                    }
                    ScreenTab.CATALOG -> {
                        CatalogScreen(
                            titles = filteredTitles,
                            favorites = favorites,
                            searchQuery = searchQuery,
                            selectedCategory = selectedCategory,
                            selectedGenre = selectedGenre,
                            selectedStatus = selectedStatus,
                            selectedSort = selectedSort,
                            onSearchChange = { viewModel.setSearchQuery(it) },
                            onCategoryChange = { viewModel.setCategory(it) },
                            onGenreChange = { viewModel.setGenre(it) },
                            onStatusChange = { viewModel.setStatus(it) },
                            onSortChange = { viewModel.setSort(it) },
                            onTitleClick = { viewModel.openDetail(it) },
                            onFavoriteToggle = { viewModel.toggleFavorite(it) }
                        )
                    }
                    ScreenTab.FAVORITES -> {
                        val favoriteList = titles.filter { favorites.contains(it.id) }
                        FavoritesScreen(
                            favoriteTitles = favoriteList,
                            onTitleClick = { viewModel.openDetail(it) },
                            onWatchClick = { title, ep -> viewModel.openWatch(title, ep) },
                            onRemoveFavorite = { viewModel.toggleFavorite(it) }
                        )
                    }
                    ScreenTab.HISTORY -> {
                        HistoryScreen(
                            historyItems = history,
                            titles = titles,
                            onWatchClick = { title, ep -> viewModel.openWatch(title, ep) },
                            onClearHistory = { viewModel.clearHistory() }
                        )
                    }
                    ScreenTab.VIP -> {
                        VipScreen(
                            user = userProfile,
                            onPlanSelect = { viewModel.openPayment(it) }
                        )
                    }
                    ScreenTab.PROFILE -> {
                        ProfileScreen(
                            user = userProfile,
                            isAdmin = isAdmin,
                            onAvatarClick = { viewModel.openAvatarModal() },
                            onMeditationClick = { viewModel.openMeditation() },
                            onAdminClick = { viewModel.openAdmin() },
                            onVipClick = { viewModel.selectTab(ScreenTab.VIP) },
                            onClearHistory = { viewModel.clearHistory() }
                        )
                    }
                }
            }

            // Level Up / Celebration Floating Overlay Banner
            AnimatedVisibility(
                visible = levelUpCelebration != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(14.dp)
            ) {
                Surface(
                    color = BloodDeep,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, QiGold, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Celebration,
                            contentDescription = null,
                            tint = QiGold,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = levelUpCelebration ?: "",
                            color = QiGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.clearCelebration() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Tutup",
                                tint = TextPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Detail Modal Dialog
            detailModalTitle?.let { title ->
                DetailDialog(
                    title = title,
                    isFavorite = favorites.contains(title.id),
                    onDismiss = { viewModel.closeDetail() },
                    onWatchClick = { episode -> viewModel.openWatch(title, episode) },
                    onToggleFavorite = { viewModel.toggleFavorite(title.id) }
                )
            }

            // Payment Modal Dialog
            showPaymentDialog?.let { plan ->
                PaymentDialog(
                    plan = plan,
                    onDismiss = { viewModel.closePayment() },
                    onConfirm = { viewModel.confirmPayment(it) }
                )
            }

            // Avatar Modal Dialog
            if (showAvatarDialog) {
                AvatarDialog(
                    currentSymbol = userProfile.avatarSymbol,
                    onDismiss = { viewModel.closeAvatarModal() },
                    onSelectAvatar = { symbol, color -> viewModel.selectAvatar(symbol, color) }
                )
            }

            // Meditation Modal Dialog
            if (showMeditationDialog) {
                MeditationDialog(
                    user = userProfile,
                    onDismiss = { viewModel.closeMeditation() },
                    onMeditate = { viewModel.executeMeditation() }
                )
            }

            // Admin Modal Dialog
            if (showAdminDialog) {
                AdminDialog(
                    isAdmin = isAdmin,
                    titles = titles,
                    onDismiss = { viewModel.closeAdmin() },
                    onLogin = { viewModel.loginAdmin(it) },
                    onLogout = { viewModel.logoutAdmin() },
                    onAddTitle = { title, type, genre, status, symbol, episodes, synopsis, videoUrlsText ->
                        viewModel.addCustomAnime(title, type, genre, status, symbol, episodes, synopsis, videoUrlsText)
                    },
                    onPostAnnouncement = { title, content, tag ->
                        viewModel.postAnnouncement(title, content, tag)
                    },
                    onBoostExp = { viewModel.boostExp(it) },
                    onSetVideoUrls = { titleId, videoUrlsText ->
                        viewModel.setTitleVideoUrls(titleId, videoUrlsText)
                    }
                )
            }

            // Ad Break Modal Dialog
            if (showAdModal) {
                AdBreakDialog(
                    onContinue = { viewModel.skipAdAndContinue() },
                    onUpgradeVip = {
                        viewModel.skipAdAndContinue()
                        viewModel.selectTab(ScreenTab.VIP)
                    }
                )
            }
        }
    }
}
