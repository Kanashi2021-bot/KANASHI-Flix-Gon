package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val KanashiColorScheme = darkColorScheme(
    primary = BloodPrimary,
    onPrimary = Color.White,
    primaryContainer = BloodDeep,
    onPrimaryContainer = Color.White,
    secondary = QiGold,
    onSecondary = Color.Black,
    secondaryContainer = QiGoldDark,
    onSecondaryContainer = Color.White,
    tertiary = SpiritJade,
    onTertiary = Color.Black,
    background = BloodBg,
    onBackground = TextPrimary,
    surface = BloodSurface,
    onSurface = TextPrimary,
    surfaceVariant = BloodSurfaceVariant,
    onSurfaceVariant = TextMuted,
    outline = CardBorder,
    outlineVariant = BorderSubtle
)

@Composable
fun KanashiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = KanashiColorScheme,
        typography = AppTypography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    KanashiTheme(content = content)
}
