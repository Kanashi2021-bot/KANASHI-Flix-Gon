package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.videoUrlsToText
import com.example.model.AnimeTitle
import com.example.ui.theme.BloodDeep
import com.example.ui.theme.BloodPrimary
import com.example.ui.theme.BloodPrimaryDark
import com.example.ui.theme.BloodSurface
import com.example.ui.theme.BloodSurfaceElevated
import com.example.ui.theme.CinzelFontFamily
import com.example.ui.theme.QiGold
import com.example.ui.theme.SpiritJade
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun AdminDialog(
    isAdmin: Boolean,
    titles: List<AnimeTitle> = emptyList(),
    onDismiss: () -> Unit,
    onLogin: (String) -> Boolean,
    onLogout: () -> Unit,
    onAddTitle: (title: String, type: String, genre: String, status: String, symbol: String, episodes: Int, synopsis: String, videoUrlsText: String) -> Unit,
    onPostAnnouncement: (title: String, content: String, tag: String) -> Unit,
    onBoostExp: (Int) -> Unit,
    onSetVideoUrls: (titleId: Int, videoUrlsText: String) -> Unit
) {
    var password by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Tambah Judul, 1: Warta, 2: EXP

    // Form inputs for title
    var newTitle by remember { mutableStateOf("") }
    var newType by remember { mutableStateOf("Donghua") }
    var newGenre by remember { mutableStateOf("Cultivation") }
    var newStatus by remember { mutableStateOf("Ongoing") }
    var newSymbol by remember { mutableStateOf("武") }
    var newEpisodes by remember { mutableStateOf("12") }
    var newSynopsis by remember { mutableStateOf("") }
    var newVideoUrls by remember { mutableStateOf("") }
    // Editor URL video (tab "Sumber Video")
    var selectedVideoTitleId by remember { mutableIntStateOf(-1) }
    var videoUrlEditorText by remember { mutableStateOf("") }

    // Form inputs for announcement
    var annTitle by remember { mutableStateOf("") }
    var annContent by remember { mutableStateOf("") }
    var annTag by remember { mutableStateOf("UPDATE") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = BloodSurfaceElevated,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .border(1.dp, QiGold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .testTag("admin_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = QiGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Ruang Tetua Sekte",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = CinzelFontFamily,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Tutup",
                            tint = TextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (!isAdmin) {
                    // Password Login Form
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(30.dp))
                                .background(BloodDeep),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = QiGold,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Gerbang Tertutup",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "Masukkan kunci sandi Tetua Sekte untuk mengelola konten dan warta.",
                            color = TextMuted,
                            fontSize = 11.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Kunci Sandi", color = TextMuted) },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_password_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = BloodSurface,
                                unfocusedContainerColor = BloodSurface,
                                focusedBorderColor = QiGold,
                                unfocusedBorderColor = Color(0x30FFFFFF),
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Kunci Master: Mamas2021",
                                color = TextMuted,
                                fontSize = 10.sp,
                                modifier = Modifier.clickable { password = "Mamas2021" }
                            )

                            Button(
                                onClick = {
                                    onLogin(password)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = QiGold,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("admin_login_submit")
                            ) {
                                Text("Buka Gerbang", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    // Admin Active Panels
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AdminSubTab(
                            title = "Tambah Judul",
                            isSelected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            modifier = Modifier.weight(1f)
                        )
                        AdminSubTab(
                            title = "Warta Sekte",
                            isSelected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            modifier = Modifier.weight(1f)
                        )
                        AdminSubTab(
                            title = "EXP Ranah",
                            isSelected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            modifier = Modifier.weight(1f)
                        )
                        AdminSubTab(
                            title = "Sumber Video",
                            isSelected = selectedTab == 3,
                            onClick = { selectedTab = 3 },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    when (selectedTab) {
                        0 -> {
                            // Add New Title Form
                            Text("Judul Karya Baru", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = newTitle,
                                onValueChange = { newTitle = it },
                                placeholder = { Text("Contoh: Against the Gods", color = TextMuted) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Format", color = TextMuted, fontSize = 10.sp)
                                    OutlinedTextField(
                                        value = newType,
                                        onValueChange = { newType = it },
                                        singleLine = true
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Genre", color = TextMuted, fontSize = 10.sp)
                                    OutlinedTextField(
                                        value = newGenre,
                                        onValueChange = { newGenre = it },
                                        singleLine = true
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Simbol Kanji", color = TextMuted, fontSize = 10.sp)
                                    OutlinedTextField(
                                        value = newSymbol,
                                        onValueChange = { newSymbol = it },
                                        singleLine = true
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Total Episode", color = TextMuted, fontSize = 10.sp)
                                    OutlinedTextField(
                                        value = newEpisodes,
                                        onValueChange = { newEpisodes = it },
                                        singleLine = true
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text("Sinopsis Alur Cerita", color = TextMuted, fontSize = 10.sp)
                            OutlinedTextField(
                                value = newSynopsis,
                                onValueChange = { newSynopsis = it },
                                placeholder = { Text("Deskripsi donghua/anime...", color = TextMuted) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "URL Video Asli per Episode (opsional, satu per baris: nomorEpisode=url)",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                            OutlinedTextField(
                                value = newVideoUrls,
                                onValueChange = { newVideoUrls = it },
                                placeholder = {
                                    Text(
                                        "1=https://server.com/ep1.mp4\n2=https://server.com/ep2.mp4",
                                        color = TextMuted,
                                        fontSize = 11.sp
                                    )
                                },
                                singleLine = false,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(100.dp)
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = {
                                    if (newTitle.isNotBlank()) {
                                        onAddTitle(
                                            newTitle,
                                            newType,
                                            newGenre,
                                            newStatus,
                                            newSymbol,
                                            newEpisodes.toIntOrNull() ?: 12,
                                            newSynopsis,
                                            newVideoUrls
                                        )
                                        newTitle = ""
                                        newSynopsis = ""
                                        newVideoUrls = ""
                                        onDismiss()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BloodPrimary,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(imageVector = Icons.Default.AddCircle, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Terbitkan ke Katalog", fontWeight = FontWeight.Bold)
                            }
                        }

                        1 -> {
                            // Announcement Form
                            Text("Judul Warta / Pengumuman", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = annTitle,
                                onValueChange = { annTitle = it },
                                placeholder = { Text("Contoh: Pembaruan Server v2.6", color = TextMuted) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text("Kategori Tag", color = TextMuted, fontSize = 10.sp)
                            OutlinedTextField(
                                value = annTag,
                                onValueChange = { annTag = it },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text("Isi Pengumuman", color = TextMuted, fontSize = 10.sp)
                            OutlinedTextField(
                                value = annContent,
                                onValueChange = { annContent = it },
                                placeholder = { Text("Pesan untuk seluruh kultivator...", color = TextMuted) },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = {
                                    if (annTitle.isNotBlank()) {
                                        onPostAnnouncement(annTitle, annContent, annTag)
                                        annTitle = ""
                                        annContent = ""
                                        onDismiss()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = QiGold,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(imageVector = Icons.Default.Campaign, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Terbitkan Warta", fontWeight = FontWeight.Bold)
                            }
                        }

                        2 -> {
                            // Cultivation Boost Actions
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = "Bantuan Spiritual Tetua",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Gunakan kekuatan Tetua Sekte untuk memberikan suntikan Qi kultivasi instan.",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )

                                Button(
                                    onClick = { onBoostExp(500) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SpiritJade,
                                        contentColor = Color.Black
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(imageVector = Icons.Default.Bolt, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Suntik +500 Qi EXP Instan", fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { onBoostExp(2000) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = QiGold,
                                        contentColor = Color.Black
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(imageVector = Icons.Default.Bolt, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Terobosan Ranah Besar (+2.000 EXP)", fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedButton(
                                    onClick = {
                                        onLogout()
                                        onDismiss()
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Keluar dari Mode Tetua Admin", color = BloodPrimary)
                                }
                            }
                        }
                        3 -> {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "Atur URL Video Asli per Episode",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Pilih judul, lalu tempel alamat video asli. Format: nomorEpisode=url (satu per baris). Kosongkan untuk menghapus.",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    titles.forEach { t ->
                                        val sel = selectedVideoTitleId == t.id
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (sel) BloodPrimary else BloodSurface)
                                                .border(
                                                    1.dp,
                                                    if (sel) QiGold else Color(0x25FFFFFF),
                                                    RoundedCornerShape(8.dp)
                                                )
                                                .clickable { selectedVideoTitleId = t.id }
                                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                        ) {
                                            Text(
                                                text = t.title,
                                                color = if (sel) Color.White else TextPrimary,
                                                fontSize = 11.sp,
                                                fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }
                                LaunchedEffect(selectedVideoTitleId) {
                                    val t = titles.firstOrNull { it.id == selectedVideoTitleId }
                                    videoUrlEditorText = videoUrlsToText(t?.videoUrls ?: emptyMap())
                                }
                                OutlinedTextField(
                                    value = videoUrlEditorText,
                                    onValueChange = { videoUrlEditorText = it },
                                    placeholder = {
                                        Text(
                                            "1=https://server.com/ep1.mp4\n2=https://server.com/ep2.mp4",
                                            color = TextMuted,
                                            fontSize = 11.sp
                                        )
                                    },
                                    singleLine = false,
                                    enabled = selectedVideoTitleId != -1,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(140.dp)
                                )
                                Button(
                                    onClick = {
                                        if (selectedVideoTitleId != -1) {
                                            onSetVideoUrls(selectedVideoTitleId, videoUrlEditorText)
                                            onDismiss()
                                        }
                                    },
                                    enabled = selectedVideoTitleId != -1,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = BloodPrimary,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(imageVector = Icons.Default.PlayCircle, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Simpan Sumber Video Asli", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminSubTab(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) QiGold.copy(alpha = 0.25f) else BloodSurface)
            .border(
                1.dp,
                if (isSelected) QiGold else Color(0x20FFFFFF),
                RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = if (isSelected) QiGold else TextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
