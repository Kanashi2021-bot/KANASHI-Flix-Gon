package com.example.model

data class AnimeTitle(
    val id: Int,
    val title: String,
    val type: String, // "Donghua" or "Anime"
    val genre: String, // "Cultivation", "Fantasy", "Action", "Adventure", "Supernatural", "Romance", "Comedy"
    val status: String, // "Ongoing" or "Selesai"
    val symbol: String, // Chinese/Kanji character
    val glowColor: String, // Hex color for atmospheric glow
    val rating: String,
    val totalEpisodes: Int,
    val synopsis: String,
    val videoUrls: Map<Int, String> = emptyMap(),
    val isVipExclusive: Boolean = false,
    val releaseYear: String = "2024",
    val studio: String = "Sparkly Key / Tencent / Mappa",
    val posterUrl: String = ""
)

data class UserProfile(
    val name: String = "Pendekar Bayangan",
    val email: String = "pendekar@sekte.kanashi",
    val sect: String = "Sekte Pedang Darah",
    val avatarSymbol: String = "影",
    val avatarColorHex: String = "#E11D35",
    val level: Int = 15,
    val exp: Int = 420,
    val expToNextLevel: Int = 1000,
    val isVip: Boolean = false,
    val vipDaysRemaining: Int = 0,
    val vipTier: String = "Biasa",
    val episodesWatched: Int = 8,
    val totalWatchMinutes: Int = 192,
    val joinedDate: String = "14 Okt 2024",
    val lastMeditationDate: String = ""
)

data class WatchHistoryItem(
    val titleId: Int,
    val title: String,
    val symbol: String,
    val type: String,
    val episode: Int,
    val progressPercent: Float, // 0.0 to 1.0
    val timestamp: Long = System.currentTimeMillis()
)

data class EpisodeComment(
    val id: String,
    val titleId: Int,
    val episode: Int,
    val authorName: String,
    val authorRank: String,
    val authorAvatar: String,
    val isVip: Boolean,
    val content: String,
    val likes: Int,
    val isLiked: Boolean = false,
    val timestampFormatted: String
)

data class VipPlan(
    val id: Int,
    val name: String,
    val price: Long,
    val days: Int,
    val expBonus: Int,
    val isFeatured: Boolean = false,
    val description: String
)

data class SectAnnouncement(
    val id: String,
    val title: String,
    val content: String,
    val date: String,
    val tag: String, // "UPDATE", "EVENT", "VIP", "PENGUMUMAN"
    val isRead: Boolean = false
)

enum class ScreenTab {
    HOME,
    CATALOG,
    FAVORITES,
    HISTORY,
    VIP,
    PROFILE
}
