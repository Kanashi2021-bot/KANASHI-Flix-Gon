package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AnimeTitle
import com.example.model.SectAnnouncement
import com.example.model.UserProfile
import com.example.model.WatchHistoryItem
import com.example.ui.components.AnimeCard
import com.example.ui.components.CultivationStatusBar
import com.example.ui.components.FilterChipsRow
import com.example.ui.theme.BloodDeep
import com.example.ui.theme.BloodPrimary
import com.example.ui.theme.BloodPrimaryDark
import com.example.ui.theme.BloodSurface
import com.example.ui.theme.BloodSurfaceElevated
import com.example.ui.theme.CinzelFontFamily
import com.example.ui.theme.QiGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun HomeScreen(
    titles: List<AnimeTitle>,
    user: UserProfile,
    favorites: Set<Int>,
    history: List<WatchHistoryItem>,
    announcements: List<SectAnnouncement>,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit,
    onTitleClick: (AnimeTitle) -> Unit,
    onFavoriteToggle: (Int) -> Unit,
    onWatchClick: (AnimeTitle, Int) -> Unit,
    onMeditationClick: () -> Unit,
    onExploreCatalog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ongoingTitles = titles.filter { it.status.equals("Ongoing", ignoreCase = true) }
    val donghuaTitles = titles.filter { it.type.equals("Donghua", ignoreCase = true) }
    val animeTitles = titles.filter { it.type.equals("Anime", ignoreCase = true) }
    val featuredTitle = titles.firstOrNull()

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Hero Banner Item
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0x35E11D35), RoundedCornerShape(16.dp))
                    .testTag("hero_banner")
            ) {
                // Background image
                Image(
                    painter = painterResource(id = R.drawable.img_hero_banner),
                    contentDescription = "Hero Cultivation Banner",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp),
                    contentScale = ContentScale.Crop
                )

                // Dark gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0xB0080708),
                                    Color(0xF5080708)
                                )
                            )
                        )
                )

                // Banner Content
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .padding(18.dp),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(BloodDeep)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "KANASHI-FLIX • BLOOD REALM",
                            color = QiGold,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Bangkitlah.\nTaklukkan Alam Semesta.",
                        style = MaterialTheme.typography.displaySmall.copy(
                            fontFamily = CinzelFontFamily,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 26.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Ribuan episode Donghua & Anime kualitas tinggi dengan sistem peningkatan ranah kultivasi.",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        maxLines = 2
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (featuredTitle != null) {
                                    onWatchClick(featuredTitle, 1)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BloodPrimary,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                            modifier = Modifier.testTag("hero_play_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Tonton Unggulan",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = onExploreCatalog,
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = QiGold
                            ),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.linearGradient(listOf(QiGold, BloodPrimary))
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier.testTag("hero_explore_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Explore,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Katalog Lengkap",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Cultivation Status Bar
        item {
            Box(modifier = Modifier.padding(horizontal = 14.dp)) {
                CultivationStatusBar(
                    user = user,
                    onMeditationClick = onMeditationClick
                )
            }
        }

        // Resume Watching Section (if history exists)
        if (history.isNotEmpty()) {
            item {
                val latest = history.first()
                val matchedTitle = titles.find { it.id == latest.titleId }
                Column(modifier = Modifier.padding(horizontal = 14.dp)) {
                    Text(
                        text = "◷ Lanjutkan Menonton",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = BloodSurfaceElevated,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, BloodPrimaryDark.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .clickable {
                                if (matchedTitle != null) {
                                    onWatchClick(matchedTitle, latest.episode)
                                }
                            }
                            .testTag("resume_watch_card")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(BloodDeep),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = latest.symbol,
                                    color = QiGold,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = latest.title,
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                                Text(
                                    text = "Episode ${latest.episode} • Terakhir Ditonton",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                            Button(
                                onClick = {
                                    if (matchedTitle != null) {
                                        onWatchClick(matchedTitle, latest.episode)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BloodPrimary,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Lanjut", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Sect Announcements Banner
        if (announcements.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(horizontal = 14.dp)) {
                    val firstAnn = announcements.first()
                    Surface(
                        color = Color(0x20D6B477),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, QiGold.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = "Warta Sekte",
                                tint = QiGold,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = firstAnn.title,
                                    color = QiGold,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = firstAnn.content,
                                    color = TextPrimary.copy(alpha = 0.85f),
                                    fontSize = 10.sp,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }
        }

        // Categories Switcher
        item {
            Column(modifier = Modifier.padding(horizontal = 14.dp)) {
                Text(
                    text = "Kategori Pilihan",
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                FilterChipsRow(
                    items = listOf("Semua", "Donghua", "Anime"),
                    selectedItem = selectedCategory,
                    onItemSelected = onCategorySelected
                )
            }
        }

        // Section: ONGOING - Sedang Tayang
        item {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🔥 ONGOING — Sedang Tayang",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Lihat Semua",
                        color = BloodPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { onExploreCatalog() }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(ongoingTitles, key = { it.id }) { anime ->
                        AnimeCard(
                            anime = anime,
                            isFavorite = favorites.contains(anime.id),
                            onCardClick = { onTitleClick(anime) },
                            onFavoriteClick = { onFavoriteToggle(anime.id) },
                            modifier = Modifier.width(140.dp)
                        )
                    }
                }
            }
        }

        // Section: Dunia Donghua
        item {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🐉 Dunia Donghua",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Lihat Semua",
                        color = BloodPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { onExploreCatalog() }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(donghuaTitles, key = { it.id }) { anime ->
                        AnimeCard(
                            anime = anime,
                            isFavorite = favorites.contains(anime.id),
                            onCardClick = { onTitleClick(anime) },
                            onFavoriteClick = { onFavoriteToggle(anime.id) },
                            modifier = Modifier.width(140.dp)
                        )
                    }
                }
            }
        }

        // Section: Anime Terpopuler
        item {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "⚔️ Anime Terpopuler",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Lihat Semua",
                        color = BloodPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { onExploreCatalog() }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(animeTitles, key = { it.id }) { anime ->
                        AnimeCard(
                            anime = anime,
                            isFavorite = favorites.contains(anime.id),
                            onCardClick = { onTitleClick(anime) },
                            onFavoriteClick = { onFavoriteToggle(anime.id) },
                            modifier = Modifier.width(140.dp)
                        )
                    }
                }
            }
        }
    }
}
