package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BloodBg = Color(0xFF080708)
val BloodSurface = Color(0xFF131011)
val BloodSurfaceVariant = Color(0xFF1D1517)
val BloodSurfaceElevated = Color(0xFF251116)
val BloodPrimary = Color(0xFFE11D35)
val BloodPrimaryDark = Color(0xFF8F0C20)
val BloodDeep = Color(0xFF500817)
val QiGold = Color(0xFFD6B477)
val QiGoldDark = Color(0xFF71501B)
val SpiritJade = Color(0xFF64E6A0)
val TextPrimary = Color(0xFFF8F5F5)
val TextMuted = Color(0xFFA69B9E)
val CardBorder = Color(0x25E11D35)
val BorderSubtle = Color(0x15FFFFFF)
