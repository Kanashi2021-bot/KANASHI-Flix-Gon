package com.example.ui.components

import coil.compose.AsyncImage\nimport androidx.compose.ui.layout.ContentScale\nimport androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CultivationRanks
import com.example.model.AnimeTitle
import com.example.model.ScreenTab
import com.example.model.UserProfile
import com.example.ui.theme.BloodBg
import com.example.ui.theme.BloodDeep
import com.example.ui.theme.BloodPrimary
import com.example.ui.theme.BloodPrimaryDark
import com.example.ui.theme.BloodSurface
import com.example.ui.theme.BloodSurfaceElevated
import com.example.ui.theme.BloodSurfaceVariant
import com.example.ui.theme.CinzelFontFamily
import com.example.ui.theme.QiGold
import com.example.ui.theme.QiGoldDark
import com.example.ui.theme.SpiritJade
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun KanashiTopHeader(
    user: UserProfile,
    isAdmin: Boolean,
    onAvatarClick: () -> Unit,
    onAdminClick: () -> Unit,
    onSearchClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = BloodBg.copy(alpha = 0.95f),
        modifier = modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = Color(0x30E11D35))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand Logo
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.testTag("brand_header")
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(BloodPrimaryDark, BloodPrimary)
                            )
                        )
                        .border(1.dp, QiGold.copy(alpha = 0.6f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "影",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "KANASHI-",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = CinzelFontFamily,
                                fontWeight = FontWeight.ExtraBold,
                                color = TextPrimary,
                                letterSpacing = 1.sp
                            )
                        )
                        Text(
                            text = "FLIX",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = CinzelFontFamily,
                                fontWeight = FontWeight.ExtraBold,
                                color = BloodPrimary,
                                letterSpacing = 1.sp
                            )
                        )
                    }
                    Text(
                        text = "BLOOD REALM",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = QiGold,
                            letterSpacing = 1.5.sp,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            // Right Actions
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onSearchClick,
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("search_action_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Cari Judul",
                        tint = TextPrimary
                    )
                }

                if (isAdmin) {
                    IconButton(
                        onClick = onAdminClick,
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("admin_action_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Panel Tetua",
                            tint = QiGold
                        )
                    }
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Avatar Icon with Rank/VIP Badge
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            try {
                                Color(android.graphics.Color.parseColor(user.avatarColorHex))
                            } catch (e: Exception) {
                                BloodPrimaryDark
                            }
                        )
                        .border(
                            width = 1.5.dp,
                            color = if (user.isVip) SpiritJade else QiGold,
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable(onClick = onAvatarClick)
                        .testTag("avatar_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = user.avatarSymbol,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )

                    if (user.isVip) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(SpiritJade),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("✓", color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CultivationStatusBar(
    user: UserProfile,
    onMeditationClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val rankTitle = CultivationRanks.getRankTitle(user.level)
    val progress = (user.exp.toFloat() / user.expToNextLevel.toFloat()).coerceIn(0f, 1f)

    Surface(
        color = BloodSurface,
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0x30E11D35), RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(BloodDeep)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "RANAH KULTIVASI",
                            color = BloodPrimary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }

                    if (user.isVip) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(QiGold.copy(alpha = 0.2f))
                                .border(1.dp, QiGold, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = "VIP",
                                    tint = SpiritJade,
                                    modifier = Modifier.size(10.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "2x EXP VIP",
                                    color = QiGold,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Text(
                    text = user.sect,
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = rankTitle,
                        color = TextPrimary,
                        fontFamily = CinzelFontFamily,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Tingkat ${user.level} • ${user.exp} / ${user.expToNextLevel} Qi EXP",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }

                Button(
                    onClick = onMeditationClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = QiGold.copy(alpha = 0.2f),
                        contentColor = QiGold
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("meditation_button")
                ) {
                    Text(
                        text = "Meditasi Harian",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Progress bar
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = BloodPrimary,
                trackColor = Color(0x33FFFFFF)
            )
        }
    }
}

@Composable
fun AnimeCard(
    anime: AnimeTitle,
    isFavorite: Boolean,
    onCardClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = BloodSurface,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0x20FFFFFF), RoundedCornerShape(12.dp))
            .clickable(onClick = onCardClick)
            .testTag("anime_card_${anime.id}")
    ) {
        Column {
            // Poster Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                try {
                                    Color(android.graphics.Color.parseColor(anime.glowColor))
                                } catch (e: Exception) {
                                    BloodDeep
                                },
                                BloodBg
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (anime.posterUrl.isNotBlank()) {
                    AsyncImage(
                        model = anime.posterUrl,
                        contentDescription = "Poster ${anime.title}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().height(145.dp)
                    )
                } else {
                    // Placeholder while the matching cover is being fetched.
                    Text(
                        text = anime.symbol,
                        color = Color.White.copy(alpha = 0.35f),
                        fontSize = 54.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                // Top Left Type/Status Badge
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xDD080607))
                        .border(1.dp, Color(0x30FFFFFF), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "${anime.type} • ${anime.status}",
                        color = TextPrimary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Top Right Favorite Heart
                IconButton(
                    onClick = onFavoriteClick,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(32.dp)
                        .testTag("fav_btn_${anime.id}")
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorit",
                        tint = if (isFavorite) BloodPrimary else Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Bottom Left Rating
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xCC000000))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Rating",
                            tint = QiGold,
                            modifier = Modifier.size(11.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = anime.rating,
                            color = QiGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Bottom Right Episode Count
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(BloodPrimary.copy(alpha = 0.85f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${anime.totalEpisodes} EP",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            // Info Box
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = anime.title,
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = anime.genre,
                        color = BloodPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = anime.releaseYear,
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
fun FilterChipsRow(
    items: List<String>,
    selectedItem: String,
    onItemSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEach { item ->
            val isSelected = item.equals(selectedItem, ignoreCase = true)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (isSelected) BloodPrimary.copy(alpha = 0.2f) else BloodSurface
                    )
                    .border(
                        1.dp,
                        if (isSelected) BloodPrimary else Color(0x22FFFFFF),
                        RoundedCornerShape(8.dp)
                    )
                    .clickable { onItemSelected(item) }
                    .padding(horizontal = 14.dp, vertical = 7.dp)
                    .testTag("chip_$item")
            ) {
                Text(
                    text = item,
                    color = if (isSelected) Color.White else TextMuted,
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun KanashiBottomNav(
    currentTab: ScreenTab,
    favoritesCount: Int,
    historyCount: Int,
    onTabSelected: (ScreenTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        containerColor = BloodBg,
        tonalElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .border(1.dp, Color(0x25E11D35))
    ) {
        NavigationBarItem(
            selected = currentTab == ScreenTab.HOME,
            onClick = { onTabSelected(ScreenTab.HOME) },
            icon = {
                Icon(imageVector = Icons.Default.Home, contentDescription = "Beranda")
            },
            label = { Text("Beranda", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BloodPrimary,
                selectedTextColor = BloodPrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted,
                indicatorColor = BloodDeep
            ),
            modifier = Modifier.testTag("nav_home")
        )

        NavigationBarItem(
            selected = currentTab == ScreenTab.CATALOG,
            onClick = { onTabSelected(ScreenTab.CATALOG) },
            icon = {
                Icon(imageVector = Icons.Default.VideoLibrary, contentDescription = "Katalog")
            },
            label = { Text("Katalog", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BloodPrimary,
                selectedTextColor = BloodPrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted,
                indicatorColor = BloodDeep
            ),
            modifier = Modifier.testTag("nav_catalog")
        )

        NavigationBarItem(
            selected = currentTab == ScreenTab.FAVORITES,
            onClick = { onTabSelected(ScreenTab.FAVORITES) },
            icon = {
                BadgedBox(badge = {
                    if (favoritesCount > 0) {
                        Badge(containerColor = BloodPrimary) {
                            Text("$favoritesCount", color = Color.White)
                        }
                    }
                }) {
                    Icon(imageVector = Icons.Default.Bookmark, contentDescription = "Favorit")
                }
            },
            label = { Text("Favorit", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BloodPrimary,
                selectedTextColor = BloodPrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted,
                indicatorColor = BloodDeep
            ),
            modifier = Modifier.testTag("nav_favorites")
        )

        NavigationBarItem(
            selected = currentTab == ScreenTab.HISTORY,
            onClick = { onTabSelected(ScreenTab.HISTORY) },
            icon = {
                BadgedBox(badge = {
                    if (historyCount > 0) {
                        Badge(containerColor = QiGoldDark) {
                            Text("$historyCount", color = Color.White)
                        }
                    }
                }) {
                    Icon(imageVector = Icons.Default.History, contentDescription = "Riwayat")
                }
            },
            label = { Text("Riwayat", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BloodPrimary,
                selectedTextColor = BloodPrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted,
                indicatorColor = BloodDeep
            ),
            modifier = Modifier.testTag("nav_history")
        )

        NavigationBarItem(
            selected = currentTab == ScreenTab.VIP,
            onClick = { onTabSelected(ScreenTab.VIP) },
            icon = {
                Icon(imageVector = Icons.Default.Diamond, contentDescription = "VIP")
            },
            label = { Text("VIP", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = QiGold,
                selectedTextColor = QiGold,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted,
                indicatorColor = BloodDeep
            ),
            modifier = Modifier.testTag("nav_vip")
        )

        NavigationBarItem(
            selected = currentTab == ScreenTab.PROFILE,
            onClick = { onTabSelected(ScreenTab.PROFILE) },
            icon = {
                Icon(imageVector = Icons.Default.Person, contentDescription = "Profil")
            },
            label = { Text("Profil", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BloodPrimary,
                selectedTextColor = BloodPrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted,
                indicatorColor = BloodDeep
            ),
            modifier = Modifier.testTag("nav_profile")
        )
    }
}
