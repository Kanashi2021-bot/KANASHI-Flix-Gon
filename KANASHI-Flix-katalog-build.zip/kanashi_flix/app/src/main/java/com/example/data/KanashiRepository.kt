package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AnimeTitle
import com.example.model.EpisodeComment
import com.example.model.SectAnnouncement
import com.example.model.UserProfile
import com.example.model.WatchHistoryItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class KanashiRepository(context: Context) {
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val posterClient = OkHttpClient.Builder()
        .callTimeout(12, TimeUnit.SECONDS)
        .build()

    private val prefs: SharedPreferences =
        context.getSharedPreferences("kanashi_realm_prefs", Context.MODE_PRIVATE)

    private val _titles = MutableStateFlow<List<AnimeTitle>>(emptyList())
    val titles: StateFlow<List<AnimeTitle>> = _titles.asStateFlow()

    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _favorites = MutableStateFlow<Set<Int>>(emptySet())
    val favorites: StateFlow<Set<Int>> = _favorites.asStateFlow()

    private val _history = MutableStateFlow<List<WatchHistoryItem>>(emptyList())
    val history: StateFlow<List<WatchHistoryItem>> = _history.asStateFlow()

    private val _comments = MutableStateFlow<List<EpisodeComment>>(emptyList())
    val comments: StateFlow<List<EpisodeComment>> = _comments.asStateFlow()

    private val _announcements = MutableStateFlow<List<SectAnnouncement>>(emptyList())
    val announcements: StateFlow<List<SectAnnouncement>> = _announcements.asStateFlow()

    private val _isAdmin = MutableStateFlow(false)
    val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

    private val _watchedEpisodesCount = MutableStateFlow(0)
    val watchedEpisodesCount: StateFlow<Int> = _watchedEpisodesCount.asStateFlow()

    init {
        loadTitles()
        loadRemoteCatalogCache()
        refreshRemoteCatalog()
        loadUserProfile()
        loadFavorites()
        loadHistory()
        loadComments()
        loadAnnouncements()
        _isAdmin.value = prefs.getBoolean("is_admin", false)
        _watchedEpisodesCount.value = prefs.getInt("watched_episodes_count", 0)
    }

    private fun loadTitles() {
        val customJson = prefs.getString("custom_titles_json", null)
        val list = InitialData.DEFAULT_TITLES.toMutableList()
        if (!customJson.isNullOrEmpty()) {
            try {
                val array = JSONArray(customJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        AnimeTitle(
                            id = obj.getInt("id"),
                            title = obj.getString("title"),
                            type = obj.getString("type"),
                            genre = obj.getString("genre"),
                            status = obj.getString("status"),
                            symbol = obj.getString("symbol"),
                            glowColor = obj.optString("glowColor", "#7E1526"),
                            rating = obj.optString("rating", "9.0"),
                            totalEpisodes = obj.optInt("totalEpisodes", 12),
                            synopsis = obj.optString("synopsis", "Donghua / Anime Sekte"),
                            releaseYear = obj.optString("releaseYear", "2024"),
                            studio = obj.optString("studio", "Sparkly Key"),
                            posterUrl = obj.optString("posterUrl", ""),
                            videoUrls = parseVideoUrlsJson(obj.optJSONObject("videoUrls"))
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // Terapkan override URL video asli (dari Panel Admin) ke setiap judul.
        val overrides = loadVideoUrlOverrides()
        val merged = list.map { t ->
            val ov = overrides[t.id]
            if (ov.isNullOrEmpty()) t else t.copy(videoUrls = t.videoUrls + ov)
        }
        _titles.value = merged
        // Resolve official cover art by title metadata (AniList). This is poster metadata only;
        // it does not provide video streams or replace Otakudesu/AniChin episode sources.
        ioScope.launch {
            merged.forEach { item ->
                if (item.posterUrl.isBlank()) {
                    val poster = findPoster(item.title, item.type) ?: return@forEach
                    val current = _titles.value
                    _titles.value = current.map { existing ->
                        if (existing.id == item.id && existing.posterUrl.isBlank()) existing.copy(posterUrl = poster)
                        else existing
                    }
                }
            }
        }
    }

    /** Loads a cached metadata catalog first; refreshes it from AniList in the background.
     * This supplies titles and cover art only, not episode video streams.
     */
    private fun loadRemoteCatalogCache() {
        val raw = prefs.getString("remote_catalog_json", null) ?: return
        try {
            val arr = JSONArray(raw)
            val cached = mutableListOf<AnimeTitle>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                cached += AnimeTitle(
                    id = o.getInt("id"), title = o.getString("title"),
                    type = o.getString("type"), genre = o.optString("genre", "Fantasy"),
                    status = o.optString("status", "Ongoing"), symbol = if (o.optString("type") == "Donghua") "中" else "影",
                    glowColor = "#7E1526", rating = o.optString("rating", "—"),
                    totalEpisodes = o.optInt("totalEpisodes", 0), synopsis = o.optString("synopsis", ""),
                    releaseYear = o.optString("releaseYear", "—"), studio = o.optString("studio", "AniList metadata"),
                    posterUrl = o.optString("posterUrl", "")
                )
            }
            mergeRemoteCatalog(cached)
        } catch (_: Exception) { }
    }

    private fun refreshRemoteCatalog() {
        ioScope.launch {
            val fetched = mutableListOf<AnimeTitle>()
            // Two pages per category, 50 entries per page. Further pages can be loaded in a later update.
            for (type in listOf("Anime", "Donghua")) {
                for (page in 1..2) {
                    val items = fetchAniListPage(page, type) ?: continue
                    fetched += items
                }
            }
            if (fetched.isNotEmpty()) {
                mergeRemoteCatalog(fetched)
                val arr = JSONArray()
                fetched.distinctBy { it.id }.forEach { t ->
                    arr.put(JSONObject().apply {
                        put("id", t.id); put("title", t.title); put("type", t.type)
                        put("genre", t.genre); put("status", t.status); put("rating", t.rating)
                        put("totalEpisodes", t.totalEpisodes); put("synopsis", t.synopsis)
                        put("releaseYear", t.releaseYear); put("studio", t.studio); put("posterUrl", t.posterUrl)
                    })
                }
                prefs.edit().putString("remote_catalog_json", arr.toString()).apply()
            }
        }
    }

    private suspend fun fetchAniListPage(page: Int, type: String): List<AnimeTitle>? = withContext(Dispatchers.IO) {
        try {
            // Build separate valid GraphQL queries for Japanese anime and Chinese donghua.
            val country = if (type == "Donghua") "CN" else "JP"
            val gql = """
                query (${ '$' }page: Int) {
                  Page(page: ${ '$' }page, perPage: 50) {
                    media(type: ANIME, countryOfOrigin: $country, sort: POPULARITY_DESC) {
                      id title { romaji english native } coverImage { extraLarge large }
                      episodes status description averageScore seasonYear genres studios(isMain: true) { nodes { name } }
                    }
                  }
                }
            """.trimIndent()
            val body = JSONObject().put("query", gql).put("variables", JSONObject().put("page", page)).toString()
            val req = Request.Builder().url("https://graphql.anilist.co")
                .post(body.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .header("Accept", "application/json")
                .header("User-Agent", "KANASHI-Flix/1.0 (Android catalog metadata)").build()
            posterClient.newCall(req).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val media = JSONObject(response.body?.string().orEmpty()).optJSONObject("data")
                    ?.optJSONObject("Page")?.optJSONArray("media") ?: return@withContext null
                buildList {
                    for (i in 0 until media.length()) {
                        val o = media.optJSONObject(i) ?: continue
                        val titleObj = o.optJSONObject("title") ?: continue
                        val title = titleObj.optString("english").takeIf { it.isNotBlank() }
                            ?: titleObj.optString("romaji").takeIf { it.isNotBlank() }
                            ?: titleObj.optString("native").takeIf { it.isNotBlank() } ?: continue
                        val cover = o.optJSONObject("coverImage")
                        val poster = cover?.optString("extraLarge").orEmpty().ifBlank { cover?.optString("large").orEmpty() }
                        val genres = o.optJSONArray("genres")
                        val genre = if (genres != null && genres.length() > 0) genres.optString(0) else "Fantasy"
                        val studios = o.optJSONObject("studios")?.optJSONArray("nodes")
                        val studio = studios?.optJSONObject(0)?.optString("name") ?: "AniList"
                        val desc = android.text.Html.fromHtml(o.optString("description"), android.text.Html.FROM_HTML_MODE_COMPACT).toString()
                        add(AnimeTitle(
                            id = -o.optInt("id"), title = title, type = type, genre = genre,
                            status = if (o.optString("status") == "FINISHED") "Selesai" else "Ongoing",
                            symbol = if (type == "Donghua") "中" else "影", glowColor = "#7E1526",
                            rating = o.optInt("averageScore").takeIf { it > 0 }?.let { "%.1f".format(Locale.US, it / 10.0) } ?: "—",
                            totalEpisodes = o.optInt("episodes"), synopsis = desc.take(900),
                            releaseYear = o.optInt("seasonYear").takeIf { it > 0 }?.toString() ?: "—",
                            studio = studio, posterUrl = poster
                        ))
                    }
                }
            }
        } catch (_: Exception) { null }
    }

    private fun mergeRemoteCatalog(remote: List<AnimeTitle>) {
        if (remote.isEmpty()) return
        val current = _titles.value
        val local = current.filter { it.id >= 0 }
        val remoteExisting = current.filter { it.id < 0 }.associateBy { it.id }
        val mergedRemote = remote.distinctBy { it.id }.map { item ->
            val old = remoteExisting[item.id]
            if (old != null && old.videoUrls.isNotEmpty()) item.copy(videoUrls = old.videoUrls) else item
        }
        _titles.value = local + mergedRemote
    }

    private suspend fun findPoster(title: String, type: String): String? = withContext(Dispatchers.IO) {
        try {
            val query = """
                query (${'$'}search: String, ${'$'}mediaType: MediaType) {
                  Media(search: ${'$'}search, type: ${'$'}mediaType) {
                    coverImage { extraLarge large }
                  }
                }
            """.trimIndent()
            val mediaType = if (type.equals("Anime", true)) "ANIME" else "ANIME"
            val payload = JSONObject()
                .put("query", query)
                .put("variables", JSONObject().put("search", title).put("mediaType", mediaType))
                .toString()
            val request = Request.Builder()
                .url("https://graphql.anilist.co")
                .post(payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .header("Accept", "application/json")
                .build()
            posterClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val media = JSONObject(response.body?.string().orEmpty())
                    .optJSONObject("data")?.optJSONObject("Media") ?: return@withContext null
                val cover = media.optJSONObject("coverImage") ?: return@withContext null
                cover.optString("extraLarge").takeIf { it.startsWith("https://") }
                    ?: cover.optString("large").takeIf { it.startsWith("https://") }
            }
        } catch (_: Exception) {
            null
        }
    }

    fun addCustomTitle(title: AnimeTitle) {
        val current = _titles.value.toMutableList()
        current.add(0, title)
        _titles.value = current
        saveCustomTitles()
    }

    private fun saveCustomTitles() {
        val customOnly = _titles.value.filter { it.id > 100 }
        val array = JSONArray()
        for (t in customOnly) {
            val obj = JSONObject().apply {
                put("id", t.id)
                put("title", t.title)
                put("type", t.type)
                put("genre", t.genre)
                put("status", t.status)
                put("symbol", t.symbol)
                put("glowColor", t.glowColor)
                put("rating", t.rating)
                put("totalEpisodes", t.totalEpisodes)
                put("synopsis", t.synopsis)
                put("releaseYear", t.releaseYear)
                put("studio", t.studio)
                put("posterUrl", t.posterUrl)
                val epObj = JSONObject()
                t.videoUrls.forEach { (ep, url) -> epObj.put(ep.toString(), url) }
                put("videoUrls", epObj)
            }
            array.put(obj)
        }
        prefs.edit().putString("custom_titles_json", array.toString()).apply()
    }

    private fun loadUserProfile() {
        val name = prefs.getString("user_name", "Pendekar Bayangan") ?: "Pendekar Bayangan"
        val email = prefs.getString("user_email", "pendekar@sekte.kanashi") ?: "pendekar@sekte.kanashi"
        val sect = prefs.getString("user_sect", "Sekte Pedang Darah") ?: "Sekte Pedang Darah"
        val symbol = prefs.getString("avatar_symbol", "影") ?: "影"
        val color = prefs.getString("avatar_color", "#E11D35") ?: "#E11D35"
        val level = prefs.getInt("user_level", 15)
        val exp = prefs.getInt("user_exp", 420)
        val isVip = prefs.getBoolean("user_is_vip", false)
        val vipDays = prefs.getInt("user_vip_days", if (isVip) 30 else 0)
        val watched = prefs.getInt("user_watched", 8)
        val watchMins = prefs.getInt("user_watch_mins", 192)
        val joined = prefs.getString("user_joined", "14 Okt 2024") ?: "14 Okt 2024"
        val lastMed = prefs.getString("user_last_med", "") ?: ""

        val expNeeded = level * 100
        _userProfile.value = UserProfile(
            name = name,
            email = email,
            sect = sect,
            avatarSymbol = symbol,
            avatarColorHex = color,
            level = level,
            exp = exp,
            expToNextLevel = expNeeded,
            isVip = isVip,
            vipDaysRemaining = vipDays,
            vipTier = if (isVip) "Murid Utama VIP" else "Biasa",
            episodesWatched = watched,
            totalWatchMinutes = watchMins,
            joinedDate = joined,
            lastMeditationDate = lastMed
        )
    }

    fun saveUserProfile(profile: UserProfile) {
        _userProfile.value = profile
        prefs.edit()
            .putString("user_name", profile.name)
            .putString("user_email", profile.email)
            .putString("user_sect", profile.sect)
            .putString("avatar_symbol", profile.avatarSymbol)
            .putString("avatar_color", profile.avatarColorHex)
            .putInt("user_level", profile.level)
            .putInt("user_exp", profile.exp)
            .putBoolean("user_is_vip", profile.isVip)
            .putInt("user_vip_days", profile.vipDaysRemaining)
            .putInt("user_watched", profile.episodesWatched)
            .putInt("user_watch_mins", profile.totalWatchMinutes)
            .putString("user_joined", profile.joinedDate)
            .putString("user_last_med", profile.lastMeditationDate)
            .apply()
    }

    fun addExp(amount: Int): Boolean {
        val curr = _userProfile.value
        var newExp = curr.exp + amount
        var newLevel = curr.level
        var leveledUp = false

        while (newExp >= newLevel * 100) {
            newExp -= newLevel * 100
            newLevel++
            leveledUp = true
        }

        val updated = curr.copy(
            level = newLevel,
            exp = newExp,
            expToNextLevel = newLevel * 100
        )
        saveUserProfile(updated)
        return leveledUp
    }

    fun performDailyMeditation(): Pair<Boolean, Int> {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val curr = _userProfile.value
        if (curr.lastMeditationDate == today) {
            return Pair(false, 0)
        }
        val expGained = if (curr.isVip) 100 else 50
        addExp(expGained)
        val updated = _userProfile.value.copy(lastMeditationDate = today)
        saveUserProfile(updated)
        return Pair(true, expGained)
    }

    fun activateVip(days: Int, expBonus: Int) {
        val curr = _userProfile.value
        val newDays = curr.vipDaysRemaining + days
        addExp(expBonus)
        val updated = _userProfile.value.copy(
            isVip = true,
            vipDaysRemaining = newDays,
            vipTier = "Murid Utama VIP"
        )
        saveUserProfile(updated)
    }

    fun recordEpisodeWatched(titleId: Int, episodeNumber: Int, title: String, symbol: String, type: String) {
        // Increment watch counters
        val curr = _userProfile.value
        val newCount = _watchedEpisodesCount.value + 1
        _watchedEpisodesCount.value = newCount
        prefs.edit().putInt("watched_episodes_count", newCount).apply()

        val expEarned = if (curr.isVip) 30 else 15
        addExp(expEarned)

        val updatedProfile = curr.copy(
            episodesWatched = curr.episodesWatched + 1,
            totalWatchMinutes = curr.totalWatchMinutes + 24
        )
        saveUserProfile(updatedProfile)

        // Add to history
        val newHistoryItem = WatchHistoryItem(
            titleId = titleId,
            title = title,
            symbol = symbol,
            type = type,
            episode = episodeNumber,
            progressPercent = 0.85f,
            timestamp = System.currentTimeMillis()
        )
        val currentHistory = _history.value.toMutableList()
        currentHistory.removeAll { it.titleId == titleId }
        currentHistory.add(0, newHistoryItem)
        _history.value = currentHistory
        saveHistory()
    }

    private fun loadFavorites() {
        val set = prefs.getStringSet("favorite_ids", emptySet()) ?: emptySet()
        _favorites.value = set.mapNotNull { it.toIntOrNull() }.toSet()
    }

    fun toggleFavorite(titleId: Int): Boolean {
        val current = _favorites.value.toMutableSet()
        val isAdded: Boolean
        if (current.contains(titleId)) {
            current.remove(titleId)
            isAdded = false
        } else {
            current.add(titleId)
            isAdded = true
        }
        _favorites.value = current
        prefs.edit().putStringSet("favorite_ids", current.map { it.toString() }.toSet()).apply()
        return isAdded
    }

    private fun loadHistory() {
        val json = prefs.getString("history_items_json", null)
        if (json.isNullOrEmpty()) {
            _history.value = listOf(
                WatchHistoryItem(1, "Battle Through the Heavens", "炎", "Donghua", 3, 0.7f),
                WatchHistoryItem(7, "Solo Leveling", "影", "Anime", 2, 0.95f),
                WatchHistoryItem(2, "Renegade Immortal", "仙", "Donghua", 1, 0.5f)
            )
            return
        }
        try {
            val arr = JSONArray(json)
            val list = mutableListOf<WatchHistoryItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    WatchHistoryItem(
                        titleId = o.getInt("titleId"),
                        title = o.getString("title"),
                        symbol = o.getString("symbol"),
                        type = o.getString("type"),
                        episode = o.getInt("episode"),
                        progressPercent = o.getDouble("progressPercent").toFloat(),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
            _history.value = list
        } catch (e: Exception) {
            _history.value = emptyList()
        }
    }

    private fun saveHistory() {
        val arr = JSONArray()
        for (item in _history.value.take(40)) {
            val o = JSONObject().apply {
                put("titleId", item.titleId)
                put("title", item.title)
                put("symbol", item.symbol)
                put("type", item.type)
                put("episode", item.episode)
                put("progressPercent", item.progressPercent.toDouble())
                put("timestamp", item.timestamp)
            }
            arr.put(o)
        }
        prefs.edit().putString("history_items_json", arr.toString()).apply()
    }

    fun clearHistory() {
        _history.value = emptyList()
        prefs.edit().remove("history_items_json").apply()
    }

    private fun loadComments() {
        _comments.value = InitialData.INITIAL_COMMENTS
    }

    fun addComment(titleId: Int, episode: Int, text: String): EpisodeComment {
        val profile = _userProfile.value
        val rank = CultivationRanks.getRankTitle(profile.level)
        val newComment = EpisodeComment(
            id = "c_${System.currentTimeMillis()}",
            titleId = titleId,
            episode = episode,
            authorName = profile.name,
            authorRank = "$rank Lv ${profile.level}",
            authorAvatar = profile.avatarSymbol,
            isVip = profile.isVip,
            content = text,
            likes = 1,
            isLiked = true,
            timestampFormatted = "Baru saja"
        )
        val current = _comments.value.toMutableList()
        current.add(0, newComment)
        _comments.value = current
        addExp(5) // Bonus 5 EXP for active martial discussion
        return newComment
    }

    fun toggleCommentLike(commentId: String) {
        val current = _comments.value.toMutableList()
        val index = current.indexOfFirst { it.id == commentId }
        if (index != -1) {
            val item = current[index]
            val newLiked = !item.isLiked
            val newLikes = if (newLiked) item.likes + 1 else (item.likes - 1).coerceAtLeast(0)
            current[index] = item.copy(isLiked = newLiked, likes = newLikes)
            _comments.value = current
        }
    }

    private fun loadAnnouncements() {
        _announcements.value = InitialData.SECT_ANNOUNCEMENTS
    }

    fun postAnnouncement(title: String, content: String, tag: String) {
        val today = SimpleDateFormat("dd MMM yyyy", Locale("id", "ID")).format(Date())
        val newAnn = SectAnnouncement(
            id = "ann_${System.currentTimeMillis()}",
            title = title,
            content = content,
            date = today,
            tag = tag
        )
        val list = _announcements.value.toMutableList()
        list.add(0, newAnn)
        _announcements.value = list
    }

    fun verifyAdmin(code: String): Boolean {
        if (code.trim() == "Mamas2021") {
            _isAdmin.value = true
            prefs.edit().putBoolean("is_admin", true).apply()
            return true
        }
        return false
    }

    fun revokeAdmin() {
        _isAdmin.value = false
        prefs.edit().putBoolean("is_admin", false).apply()
    }

    /**
     * Mengatur URL video asli per-episode untuk sebuah judul (baik judul default
     * maupun judul custom). Disimpan sebagai override agar tidak hilang saat
     * pembaruan data awal. Panggil dengan map kosong untuk menghapus override.
     */
    fun setTitleVideoUrls(titleId: Int, videoUrls: Map<Int, String>) {
        val overrides = loadVideoUrlOverrides().toMutableMap()
        if (videoUrls.isEmpty()) {
            overrides.remove(titleId)
        } else {
            overrides[titleId] = videoUrls.filterValues { it.isNotBlank() }
        }
        saveVideoUrlOverrides(overrides)
        // Segera perbarui state in-memory agar langsung dipakai pemutar.
        _titles.value = _titles.value.map { t ->
            if (t.id == titleId) t.copy(videoUrls = videoUrls.filterValues { it.isNotBlank() }) else t
        }
    }

    private fun loadVideoUrlOverrides(): Map<Int, Map<Int, String>> {
        val json = prefs.getString("video_urls_overrides_json", null) ?: return emptyMap()
        val result = mutableMapOf<Int, Map<Int, String>>()
        try {
            val root = JSONObject(json)
            val keys = root.keys()
            while (keys.hasNext()) {
                val titleIdStr = keys.next()
                val titleId = titleIdStr.toIntOrNull() ?: continue
                val epObj = root.optJSONObject(titleIdStr) ?: continue
                result[titleId] = parseVideoUrlsJson(epObj)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }

    private fun saveVideoUrlOverrides(overrides: Map<Int, Map<Int, String>>) {
        val root = JSONObject()
        overrides.forEach { (titleId, eps) ->
            val epObj = JSONObject()
            eps.forEach { (ep, url) -> epObj.put(ep.toString(), url) }
            root.put(titleId.toString(), epObj)
        }
        prefs.edit().putString("video_urls_overrides_json", root.toString()).apply()
    }

    private fun parseVideoUrlsJson(obj: JSONObject?): Map<Int, String> {
        val map = mutableMapOf<Int, String>()
        if (obj == null) return map
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val ep = k.toIntOrNull() ?: continue
            val url = obj.optString(k, "").trim()
            if (url.isNotEmpty()) map[ep] = url
        }
        return map
    }
}

/**
 * Parse teks URL video per-episode. Format per baris: `nomorEpisode=url`
 * (pemisah `=` atau `|`). Baris kosong atau diawali `#` diabaikan.
 */
fun parseVideoUrlsText(text: String): Map<Int, String> {
    val map = mutableMapOf<Int, String>()
    text.lineSequence().forEach { raw ->
        val line = raw.trim()
        if (line.isEmpty() || line.startsWith("#")) return@forEach
        val sep = line.indexOf('=').takeIf { it >= 0 }
            ?: line.indexOf('|').takeIf { it >= 0 }
            ?: return@forEach
        val epPart = line.substring(0, sep).trim()
            .removePrefix("Episode").removePrefix("episode").trim()
        val ep = epPart.toIntOrNull() ?: return@forEach
        val url = line.substring(sep + 1).trim()
        if (url.isNotEmpty()) map[ep] = url
    }
    return map
}

/** Ubah map videoUrls menjadi teks (untuk ditampilkan/diedit di form admin). */
fun videoUrlsToText(videoUrls: Map<Int, String>): String =
    videoUrls.entries.sortedBy { it.key }.joinToString("\n") { "${it.key}=${it.value}" }
