package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CultivationRanks
import com.example.model.UserProfile
import com.example.ui.theme.BloodDeep
import com.example.ui.theme.BloodPrimary
import com.example.ui.theme.BloodPrimaryDark
import com.example.ui.theme.BloodSurface
import com.example.ui.theme.BloodSurfaceElevated
import com.example.ui.theme.CinzelFontFamily
import com.example.ui.theme.QiGold
import com.example.ui.theme.SpiritJade
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun ProfileScreen(
    user: UserProfile,
    isAdmin: Boolean,
    onAvatarClick: () -> Unit,
    onMeditationClick: () -> Unit,
    onAdminClick: () -> Unit,
    onVipClick: () -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val rankTitle = CultivationRanks.getRankTitle(user.level)
    val progress = (user.exp.toFloat() / user.expToNextLevel.toFloat()).coerceIn(0f, 1f)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Profile Card
        item {
            Surface(
                color = BloodSurfaceElevated,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0x35E11D35), RoundedCornerShape(16.dp))
                    .testTag("profile_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Avatar Badge
                        Box(
                            modifier = Modifier
                                .size(68.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    try {
                                        Color(android.graphics.Color.parseColor(user.avatarColorHex))
                                    } catch (e: Exception) {
                                        BloodPrimaryDark
                                    }
                                )
                                .border(
                                    width = 2.dp,
                                    color = if (user.isVip) SpiritJade else QiGold,
                                    shape = RoundedCornerShape(16.dp)
                                )
                                .clickable(onClick = onAvatarClick),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = user.avatarSymbol,
                                color = Color.White,
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Bold
                            )

                            if (user.isVip) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(SpiritJade),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("✓", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = user.name,
                                    color = TextPrimary,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                                if (user.isVip) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.Verified,
                                        contentDescription = "VIP",
                                        tint = SpiritJade,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = user.sect,
                                color = QiGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )

                            Text(
                                text = "Bergabung sejak: ${user.joinedDate}",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }

                        IconButton(onClick = onAvatarClick) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Ubah Avatar",
                                tint = TextMuted,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Cultivation Realm Banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(BloodDeep)
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Ranah: $rankTitle",
                                    color = QiGold,
                                    fontFamily = CinzelFontFamily,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Tingkat ${user.level}",
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = BloodPrimary,
                                trackColor = Color(0x30FFFFFF)
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Qi EXP: ${user.exp} / ${user.expToNextLevel}",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                                Text(
                                    text = "${((user.exp.toFloat() / user.expToNextLevel) * 100).toInt()}% Menuju Terobosan",
                                    color = BloodPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Stats Grid (2x2)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatCard(
                        title = "TOTAL EPISODE",
                        value = "${user.episodesWatched} Ep",
                        subtitle = "${user.totalWatchMinutes} Menit Kultivasi",
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "STATUS AKUN",
                        value = if (user.isVip) "VIP AKTIF" else "BIASA",
                        subtitle = if (user.isVip) "${user.vipDaysRemaining} Hari Tersisa" else "Klik untuk VIP",
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatCard(
                        title = "PANGKAT SEKTE",
                        value = "Murid Inti",
                        subtitle = rankTitle,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "EXP MULTIPLIER",
                        value = if (user.isVip) "2.0x Qi" else "1.0x Qi",
                        subtitle = if (user.isVip) "Bonus VIP Aktif" else "Standar",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Menu Section
        item {
            Text(
                text = "Pusat Pengelolaan & Aksi",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Surface(
                color = BloodSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0x20FFFFFF), RoundedCornerShape(14.dp))
            ) {
                Column {
                    ProfileMenuItem(
                        icon = Icons.Default.SelfImprovement,
                        iconTint = QiGold,
                        title = "Meditasi Harian (Serap Qi)",
                        subtitle = "Dapatkan +50 EXP (+100 EXP VIP) setiap hari",
                        onClick = onMeditationClick
                    )
                    ProfileMenuItem(
                        icon = Icons.Default.Style,
                        iconTint = BloodPrimary,
                        title = "Ganti Segel Avatar",
                        subtitle = "Pilih karakter kanji avatar pembawa aura kultivasi",
                        onClick = onAvatarClick
                    )
                    ProfileMenuItem(
                        icon = Icons.Default.Diamond,
                        iconTint = QiGold,
                        title = "Tingkatkan ke VIP Realm",
                        subtitle = "Bebas jeda iklan & centang hijau verifikasi",
                        onClick = onVipClick
                    )
                    ProfileMenuItem(
                        icon = Icons.Default.DeleteSweep,
                        iconTint = TextMuted,
                        title = "Bersihkan Riwayat Nonton",
                        subtitle = "Hapus catatan episode yang telah ditonton",
                        onClick = onClearHistory
                    )
                    ProfileMenuItem(
                        icon = Icons.Default.AdminPanelSettings,
                        iconTint = if (isAdmin) SpiritJade else QiGold,
                        title = if (isAdmin) "Ruang Tetua Sekte (Admin Aktif)" else "Ruang Tetua Sekte (Admin)",
                        subtitle = if (isAdmin) "Akses penuh kelola katalog & sekte" else "Masukkan kunci sandi Mamas2021",
                        onClick = onAdminClick
                    )
                }
            }
        }

        // App Info
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "KANASHI-FLIX • Blood Realm v2.5",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Semua fitur berjalan 100% tanpa hambatan",
                        color = Color(0x60FFFFFF),
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = BloodSurface,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.border(1.dp, Color(0x18FFFFFF), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                color = TextMuted,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = BloodPrimary,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun ProfileMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                color = TextMuted,
                fontSize = 10.sp
            )
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(18.dp)
        )
    }
}
