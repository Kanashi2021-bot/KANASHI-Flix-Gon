package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CultivationRanks
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("KANASHI-FLIX", appName)
  }

  @Test
  fun `cultivation ranks calculation`() {
    assertEquals("Qi Condensation", CultivationRanks.getRankTitle(1))
    assertEquals("Qi Condensation", CultivationRanks.getRankTitle(100))
    assertEquals("Foundation Establishment", CultivationRanks.getRankTitle(101))
    assertEquals("Core Formation", CultivationRanks.getRankTitle(250))
    assertEquals("Nascent Soul", CultivationRanks.getRankTitle(350))
    assertEquals("Penguasa Tertinggi", CultivationRanks.getRankTitle(999))
  }
}
