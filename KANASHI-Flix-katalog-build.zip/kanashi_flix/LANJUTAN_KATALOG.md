# KANASHI-Flix — Pembaruan katalog dan build

## Yang ditambahkan pada sumber ini
- Katalog metadata jarak jauh melalui AniList GraphQL.
- Memuat hingga 100 anime Jepang dan 100 donghua produksi Tiongkok pada dua halaman awal per kategori.
- Poster, judul, ringkasan, genre, status, tahun, studio, rating, dan jumlah episode diambil dari metadata API.
- Katalog hasil sinkronisasi disimpan di SharedPreferences agar masih tersedia saat dibuka lagi tanpa jaringan.
- Judul bawaan dan judul kustom lokal tetap dipertahankan.
- Workflow GitHub Actions untuk membuat APK debug dan menyimpan APK sebagai artifact.

## Batasan yang harus diketahui
- Ini bukan daftar lengkap semua judul Otakudesu/AniChin. Sumber katalog pada perubahan ini adalah AniList, dengan 100 entri awal per kategori; pagination semua halaman belum dibuat.
- Metadata katalog dan poster bukan URL video. Katalog publik tidak otomatis memberikan hak akses atau URL streaming.
- Pemutar masih memerlukan URL media yang sah/diizinkan dan kompatibel dengan ExoPlayer yang dimasukkan melalui Panel Admin. URL halaman situs biasa bukan URL video langsung.
- Tidak ada ekstraksi URL tersembunyi, pengelakan DRM, atau penghapusan perlindungan akses.
- Build lokal belum diverifikasi di lingkungan pembuatan ZIP ini. Workflow GitHub Actions ditambahkan untuk menguji build di runner Linux.

## Build melalui GitHub Actions
1. Unggah seluruh isi folder `kanashi_flix` ke repositori GitHub.
2. Buka tab Actions.
3. Pilih workflow `Build KANASHI-Flix APK`.
4. Tekan `Run workflow`.
5. Jika selesai sukses, buka hasil run dan unduh artifact `KANASHI-Flix-debug-apk`.
